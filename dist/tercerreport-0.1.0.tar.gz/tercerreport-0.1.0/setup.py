from setuptools import setup, find_packages

setup(
    name="tercerReport",                            # Nombre del paquete
    version="0.1.0",                                # Versión inicial
    packages=find_packages(),                       # Paquetes a incluir
    description="Un paquete pip simple de saludo",  # Breve descripción
    author="Claudio Hidalgo",                       # Tu nombre
    author_email="wilfridoh721@gmail.com",          # Tu correo electrónico
    url="https://github.com/wilfridoh/tercerReport",     # URL del proyecto
)